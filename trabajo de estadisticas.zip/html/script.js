const boardElement = document.getElementById('board');
const die1Element = document.getElementById('die1');
const die2Element = document.getElementById('die2');
const rollBtn = document.getElementById('rollBtn');
const statusMsg = document.getElementById('statusMsg');
const problemModal = document.getElementById('problemModal');
const msgModal = document.getElementById('msgModal');
const msgTitle = document.getElementById('msgTitle');
const msgBody = document.getElementById('msgBody');
const closeMsgBtn = document.getElementById('closeMsgBtn');
const calcBtn = document.getElementById('calcBtn');
const resultOutput = document.getElementById('resultOutput');
const closeProblemBtn = document.getElementById('closeProblemBtn');
const welcomeModal = document.getElementById('welcomeModal');
const startGameBtn = document.getElementById('startGameBtn');
const colorOptions = document.querySelectorAll('.color-option');
let selectedColor = '#f472b6'; // Default color

// Game State
let playerPosition = 0;
const totalTiles = 20;
const tiles = [];

// Tile Types Configuration (5 of each)
// Pattern: Reset, Problem, Advance, Retreat
// 0: Reset (Start), 1: Problem, 2: Advance, 3: Retreat, 4: Reset...
const tileTypes = ['reset', 'problem', 'advance', 'retreat'];

function initBoard() {
    for (let i = 0; i < totalTiles; i++) {
        const type = tileTypes[i % 4];
        const tile = document.createElement('div');
        tile.classList.add('tile', type);
        tile.dataset.index = i;

        const number = document.createElement('span');
        number.classList.add('tile-number');
        number.textContent = i + 1;
        tile.appendChild(number);

        const icon = document.createElement('div');
        icon.classList.add('tile-icon');

        let label = '';
        switch (type) {
            case 'problem':
                icon.textContent = '📝';
                label = 'Problema';
                break;
            case 'advance':
                icon.textContent = '🚀';
                label = '+3';
                break;
            case 'retreat':
                icon.textContent = '⚠️';
                label = '-5';
                break;
            case 'reset':
                icon.textContent = i === 0 ? '🏁' : '🔄';
                label = i === 0 ? 'Inicio' : 'Reiniciar';
                break;
        }

        tile.appendChild(icon);
        const text = document.createElement('div');
        text.textContent = label;
        tile.appendChild(text);

        boardElement.appendChild(tile);
        tiles.push({ index: i, type: type });
    }

    // Add Player Token
    const token = document.createElement('div');
    token.classList.add('player-token');
    token.id = 'playerToken';
    token.style.backgroundColor = selectedColor;
    token.style.boxShadow = `0 0 15px ${selectedColor}`;
    boardElement.appendChild(token);
    updatePlayerPosition(0);
}

function updatePlayerPosition(index) {
    // Ensure index is within bounds
    if (index < 0) index = totalTiles + index; // Handle negative wrap (though logic handles it before)
    index = index % totalTiles;

    playerPosition = index;

    const targetTile = document.querySelector(`.tile[data-index="${index}"]`);
    const token = document.getElementById('playerToken');

    // Get coordinates of the target tile relative to the board
    // We can use the grid area or offsetTop/Left
    // Since we used grid-area, the tile is in a specific cell.
    // The token is absolute positioned. We need to move it to the center of the tile.

    // Simple way: append token to the tile? 
    // No, that might break layout or transition.
    // Better: Calculate position based on tile's offset.

    const tileRect = targetTile.getBoundingClientRect();
    const boardRect = boardElement.getBoundingClientRect();

    const top = tileRect.top - boardRect.top + tileRect.height / 2;
    const left = tileRect.left - boardRect.left + tileRect.width / 2;

    token.style.top = `${top}px`;
    token.style.left = `${left}px`;
}

async function rollDice() {
    rollBtn.disabled = true;
    statusMsg.textContent = "Lanzando...";

    // Animation
    for (let i = 0; i < 10; i++) {
        const r1 = Math.floor(Math.random() * 6) + 1;
        const r2 = Math.floor(Math.random() * 6) + 1;
        renderDie(die1Element, r1);
        renderDie(die2Element, r2);
        await new Promise(r => setTimeout(r, 100));
    }

    const d1 = Math.floor(Math.random() * 6) + 1;
    const d2 = Math.floor(Math.random() * 6) + 1;
    renderDie(die1Element, d1);
    renderDie(die2Element, d2);

    const move = d1 + d2;
    statusMsg.textContent = `Avanzas ${move} casillas`;

    await new Promise(r => setTimeout(r, 1000));

    let newPos = (playerPosition + move) % totalTiles;
    updatePlayerPosition(newPos);

    await new Promise(r => setTimeout(r, 500));
    handleTile(newPos);

    rollBtn.disabled = false;
}

function renderDie(dieElement, value) {
    dieElement.innerHTML = ''; // Clear existing pips
    dieElement.dataset.value = value;

    // Create pips based on value (we need max 6 pips for the grid layout to work for all numbers)
    // Actually, we can just add 'value' number of pips, but for the grid layout to work with nth-child,
    // we need to be careful.
    // The CSS uses nth-child to position pips.
    // For 1: 1 pip.
    // For 2: 2 pips.
    // ...
    // So we just need to append 'value' number of pip elements.

    for (let i = 0; i < value; i++) {
        const pip = document.createElement('div');
        pip.classList.add('pip');
        dieElement.appendChild(pip);
    }
}

function handleTile(index) {
    const type = tiles[index].type;

    if (index === 0) {
        statusMsg.textContent = "Estás en el Inicio.";
        return;
    }

    switch (type) {
        case 'problem':
            openProblemModal();
            break;
        case 'advance':
            showMsg("¡Impulso!", "Avanzas 3 casillas extra.");
            setTimeout(() => {
                let nextPos = (playerPosition + 3) % totalTiles;
                updatePlayerPosition(nextPos);
                // Recursive check? Maybe not to avoid infinite loops if bad design.
                // But user wants simple logic.
                // If I land on another special tile, should it trigger?
                // Usually yes. Let's trigger it after a delay.
                setTimeout(() => handleTile(nextPos), 1000);
            }, 1500);
            break;
        case 'retreat':
            showMsg("¡Retroceso!", "Retrocedes 5 casillas.");
            setTimeout(() => {
                let nextPos = playerPosition - 5;
                if (nextPos < 0) nextPos = totalTiles + nextPos;
                updatePlayerPosition(nextPos);
                setTimeout(() => handleTile(nextPos), 1000);
            }, 1500);
            break;
        case 'reset':
            showMsg("¡Reinicio!", "Vuelves al inicio.");
            setTimeout(() => {
                updatePlayerPosition(0);
            }, 1500);
            break;
    }
}

// Modal Logic
function showMsg(title, body) {
    msgTitle.textContent = title;
    msgBody.textContent = body;
    msgModal.classList.add('active');
}

closeMsgBtn.addEventListener('click', () => {
    msgModal.classList.remove('active');
});

function openProblemModal() {
    problemModal.classList.add('active');
    resultOutput.textContent = '';
    closeProblemBtn.classList.add('hidden');

    // Clear inputs
    document.getElementById('n-input').value = '';
    document.getElementById('p-input').value = '';
    document.getElementById('x-input').value = '';
}

const scoreCounter = document.getElementById('scoreCounter');
let problemsSolved = 0;

closeProblemBtn.addEventListener('click', () => {
    problemModal.classList.remove('active');
    statusMsg.textContent = "Problema resuelto. ¡Sigue jugando!";
    problemsSolved++;
    scoreCounter.textContent = `Problemas resueltos: ${problemsSolved}`;
});

// Binomial Logic
function factorial(n) {
    if (n === 0 || n === 1) return 1;
    let result = 1;
    for (let i = 2; i <= n; i++) result *= i;
    return result;
}

function combination(n, k) {
    if (k < 0 || k > n) return 0;
    return factorial(n) / (factorial(k) * factorial(n - k));
}

function binomialProbability(n, p, x) {
    return combination(n, x) * Math.pow(p, x) * Math.pow(1 - p, n - x);
}

calcBtn.addEventListener('click', () => {
    const n = parseInt(document.getElementById('n-input').value);
    const p = parseFloat(document.getElementById('p-input').value);
    const x = parseInt(document.getElementById('x-input').value);
    const condition = document.getElementById('condition-select').value;

    if (isNaN(n) || isNaN(p) || isNaN(x)) {
        resultOutput.textContent = "Por favor ingresa valores válidos.";
        return;
    }

    if (p < 0 || p > 1) {
        resultOutput.textContent = "La probabilidad (p) debe estar entre 0 y 1.";
        return;
    }

    let result = 0;
    let text = "";

    switch (condition) {
        case 'exact': // P(X = x)
            result = binomialProbability(n, p, x);
            text = `P(X = ${x})`;
            break;
        case 'more': // P(X > x)
            for (let i = x + 1; i <= n; i++) result += binomialProbability(n, p, i);
            text = `P(X > ${x})`;
            break;
        case 'max': // P(X <= x)
            for (let i = 0; i <= x; i++) result += binomialProbability(n, p, i);
            text = `P(X <= ${x})`;
            break;
        case 'at_least': // P(X >= x)
            for (let i = x; i <= n; i++) result += binomialProbability(n, p, i);
            text = `P(X >= ${x})`;
            break;
        case 'less': // P(X < x)
            for (let i = 0; i < x; i++) result += binomialProbability(n, p, i);
            text = `P(X < ${x})`;
            break;
    }

    resultOutput.textContent = `${text} = ${result.toFixed(4)}`;
    closeProblemBtn.classList.remove('hidden');
});

rollBtn.addEventListener('click', rollDice);

// Welcome Modal Logic
colorOptions.forEach(option => {
    option.addEventListener('click', () => {
        // Remove selected class from all
        colorOptions.forEach(opt => opt.classList.remove('selected'));
        // Add to clicked
        option.classList.add('selected');
        selectedColor = option.dataset.color;
    });
});

// Select default
document.querySelector('.color-option[data-color="#f472b6"]').classList.add('selected');

startGameBtn.addEventListener('click', () => {
    welcomeModal.classList.remove('active');
    // Update token color if already created (it is created in initBoard)
    const token = document.getElementById('playerToken');
    if (token) {
        token.style.backgroundColor = selectedColor;
        token.style.boxShadow = `0 0 15px ${selectedColor}`;
    }
});

// Init
initBoard();
// Fix initial token position after layout
window.addEventListener('resize', () => updatePlayerPosition(playerPosition));
// Small delay to ensure DOM is ready for rect calculation
setTimeout(() => updatePlayerPosition(0), 100);
